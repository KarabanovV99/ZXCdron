from django.contrib import admin
from .models import Drone, Places

admin.site.register(Places)
admin.site.register(Drone)



